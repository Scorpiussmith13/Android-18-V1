package com.example.tipcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText EnteredAmount; //here i have reference variable names same as id's of the objects
    private SeekBar  PercentageSeekbar;
    private TextView PercentageText;
    private Button CalculateButton;
    private TextView TotalTipAmountText;
    private TextView TotalAmount;
    private int tipvalue;
    private float amount=0.0f;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EnteredAmount=findViewById(R.id.EnteredAmount);
        PercentageSeekbar=findViewById(R.id.PercentageSeekbar);
        PercentageText=findViewById(R.id.PercentageText);
        CalculateButton=findViewById(R.id.CalculateButton);
        TotalTipAmountText=findViewById(R.id.TotalTipAmountText);
        TotalAmount=findViewById(R.id.TotalAmount);
        PercentageSeekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                PercentageText.setText(PercentageSeekbar.getProgress()+R.string.Percentage_sign);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            tipvalue=PercentageSeekbar.getProgress();


            }
        });

        CalculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculate();

            }
        });



    }
private void calculate(){
    if(!EnteredAmount.toString().equals("")){
        amount=Float.parseFloat(EnteredAmount.getText().toString());
        float total_tip=amount*(tipvalue)/100;

        TotalTipAmountText.setText(String.valueOf("GST amount is  ₹"+total_tip));
        float total_sum=total_tip+amount;
        TotalAmount.setText(String.valueOf("You total is ₹"+total_sum));
    }
        else{
            Toast.makeText(getApplicationContext(),"Enter Amount please",Toast.LENGTH_LONG).show();
    }
}




}