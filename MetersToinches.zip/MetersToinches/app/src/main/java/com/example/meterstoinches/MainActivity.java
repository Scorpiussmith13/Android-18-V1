package com.example.meterstoinches;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

  private   EditText enterMeters;
   private Button button;
private TextView convertTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        enterMeters=findViewById(R.id.EnterMeters);
        button=findViewById(R.id.button1);
        convertTextView=findViewById(R.id.textView1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double multiplier=39.37;
                double result;

                if(enterMeters.getText().toString().equals("")){
                    convertTextView.setVisibility(View.VISIBLE);
                    convertTextView.setTextColor(Color.RED);
                    convertTextView.setText(R.string.error_msg);


                }
                else{
                    double enterValue=Double.parseDouble(enterMeters.getText().toString());
                    result=enterValue*multiplier;
                    convertTextView.setVisibility(View.VISIBLE);
                    convertTextView.setTextColor(Color.GREEN);
                    convertTextView.setText(String.format("%.3f",result));// borrowed from C program
                }

            }
        });




    }
}
