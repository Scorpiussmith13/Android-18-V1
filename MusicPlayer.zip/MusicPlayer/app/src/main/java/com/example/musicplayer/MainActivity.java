package com.example.musicplayer;

import android.annotation.SuppressLint;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
private MediaPlayer music_player;
private SeekBar seekbar;
private TextView song_name;
private TextView artist_name;
private TextView left_timer;
private TextView right_timer;
private ImageButton prev_button;
private ImageButton play_button;
private ImageButton next_button;
private Thread thread;
private SimpleDateFormat dateFormat;

    @SuppressLint("SimpleDateFormat")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setUp();
        dateFormat= new SimpleDateFormat("mm:ss");
        int duration=music_player.getDuration();
        right_timer.setText(dateFormat.format(new Time(2000)));

        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
       @Override
       public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
           if(fromUser) {
               music_player.seekTo(progress);

           }
          int curr_pos=music_player.getCurrentPosition();

           left_timer.setText(dateFormat.format(new Date(curr_pos)));


       }

       @Override
       public void onStartTrackingTouch(SeekBar seekBar) {
           Toast.makeText(getApplicationContext(),"Started",Toast.LENGTH_SHORT).show();
       }

       @Override
       public void onStopTrackingTouch(SeekBar seekBar) {

       }
   });

    }

public void setUp(){
    music_player=MediaPlayer.create(getApplicationContext(),R.raw.hip_hop);
    seekbar=findViewById(R.id.musicSeekID);
    song_name=findViewById(R.id.songNameID);
    artist_name=findViewById(R.id.artistNameID);
    left_timer=findViewById(R.id.leftTimerID);
    right_timer = findViewById(R.id.rightTimerID);
    prev_button=findViewById(R.id.previousButtonID);
    play_button=findViewById(R.id.playButtonID);
    next_button=findViewById(R.id.nextButtonID);

    seekbar.setMax(music_player.getDuration());


    prev_button.setOnClickListener(this);
    play_button.setOnClickListener(this);
    next_button.setOnClickListener(this);
}


    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.previousButtonID:
                backPlayer();


                Toast.makeText(getApplicationContext(),"previous clicked",Toast.LENGTH_SHORT).show();
                break;
            case R.id.playButtonID:
                if(music_player.isPlaying()){
                    play_button.setBackgroundResource(android.R.drawable.ic_media_play);
                    pauseMusic();
                }
                else{
                    play_button.setBackgroundResource(android.R.drawable.ic_media_pause);
                    playMusic();
                }

                Toast.makeText(getApplicationContext(),"play clicked",Toast.LENGTH_SHORT).show();
                break;
            case R.id.nextButtonID:
                Toast.makeText(getApplicationContext(),"next clicked",Toast.LENGTH_SHORT).show();
                break;

        }
    }
    public void  playMusic(){
       if(music_player!=null)
           music_player.start();
       updateThread();
    }
    public void  pauseMusic(){
        if(music_player!=null)
            music_player.pause();
    }


    public void backPlayer(){
    if(music_player!=null){
        music_player.seekTo(0);
        seekbar.setProgress(0);
        left_timer.setText(dateFormat.format(new Date(0)));
        pauseMusic();
        play_button.setBackgroundResource(android.R.drawable.ic_media_play);

    }
    }





    public void updateThread(){
        thread =new Thread(){
            @Override
            public void run() {
                try {
                    while (music_player != null && music_player.isPlaying()) {
                        Thread.sleep(50);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                int new_position=music_player.getCurrentPosition();
                                seekbar.setProgress(new_position);
                                left_timer.setText(dateFormat.format(new Date(new_position)));

                            }

                        });
                    }
                } catch(InterruptedException e){
                    e.printStackTrace();
                }

            }
        };
        thread.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(music_player!=null && music_player.isPlaying()){
            music_player.stop();
            music_player.release();
            music_player=null;
        }
        thread.interrupt();
        thread=null;

    }

}

