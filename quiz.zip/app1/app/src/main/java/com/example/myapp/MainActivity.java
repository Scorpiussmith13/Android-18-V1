package com.example.myapp;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;

import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

private TextView score_view;



private TextView t_view;//has the answer
private TextView t_view1;
private TextView t_view2;
private EditText e_text;//user's answer
private EditText e_text1;
private EditText e_text2;

private Button m_button;

private   int score=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        e_text=findViewById(R.id.editTextTextPersonName);
        t_view=(TextView) findViewById(R.id.my_textView);
        m_button = findViewById(R.id.my_button);
        m_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              t_view.setVisibility(View.VISIBLE);
               String entered_text;
              entered_text = e_text.getText().toString();
                if (entered_text.equalsIgnoreCase(getString(R.string.answer1))) {

                    score++;
                }



                score_view.setVisibility(View.VISIBLE);
                if(score==0||score==1){
                    score_view.setText(String.format("Current score is %d",score)+" point");

                }
                else{
                    score_view.setText(String.format("Current score is %d",score)+" points");

                }





            }
        });

        m_button=findViewById(R.id.button1);
        e_text1=findViewById(R.id.question2);
        t_view1=(TextView)findViewById(R.id.textView);
        m_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t_view1.setVisibility(View.VISIBLE);
                String text;
                text=e_text1.getText().toString();

                if(text.equalsIgnoreCase(getString(R.string.answer2))){
                    score++;
                }


                score_view.setVisibility(View.VISIBLE);
                if(score==0||score==1){
                    score_view.setText(String.format("Current score is %d", score) + " point");
                }
                else{
                    score_view.setText(String.format("Current score is %d", score) + " points");

                }



            }
        });

        score_view=findViewById(R.id.scorecard);
        m_button=findViewById(R.id.button2);
        e_text2=findViewById(R.id.question3);
        t_view2=(TextView)findViewById(R.id.textView2);
        m_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t_view2.setVisibility(View.VISIBLE);
                String text;
                text=e_text2.getText().toString();

                if(text.equalsIgnoreCase(getString(R.string.answer3))){
                    score++;
                }


                score_view.setVisibility(View.VISIBLE);
                if(score==0||score==1){
                    score_view.setText(String.format("Current score is %d", score) + " point");
                }
                else{

                    score_view.setText(String.format("Current score is %d", score) + " points");
                }


            }
        });








        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action ", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }
   // public void ShowMe(View view){




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
